# AGIS Streamlit — Candidato consolidado

Fecha de armado: 03/11/2026

## Alcance
Estabilización de la aplicación que recibe CSV, GeoJSON y TIFF y genera el PDF. No se modifica el motor agronómico AGIS ni sus reglas de diagnóstico/prioridad.

## Cambios incluidos

### Lectura de archivos
- CSV: lectura con fallback de encoding, rechazo de archivo vacío y columnas duplicadas.
- GeoJSON: lectura controlada, CRS WGS84 por defecto según el estándar GeoJSON cuando no se declara, geometrías no vacías/válidas e identificación `id_unico`.
- TIFF: lectura de píxeles y metadatos por Rasterio, comprobación de 2 o 3 bandas, CRS, dimensiones y nodata real.

### Validación cruzada
- Columnas requeridas del contrato CSV.
- IDs CSV no vacíos y no duplicados.
- Prioridades reconocidas y fechas válidas.
- Correspondencia de IDs CSV ↔ GeoJSON.
- Consistencia básica del raster.
- Intersección espacial GeoJSON ↔ extensión TIFF.
- Mensajes de error por etapa en la interfaz.

### Mapas y PDF
- Se conserva `NO_CONCLUYENTE` como “No concluyente”; un número NDRE/NDMI por sí solo no se interpreta como ausencia de desviación.
- Leyenda de fichas acorde a SAR VV + NDRE y focos solo si hay geometrías de foco.
- Mensaje visible si no se puede generar un mapa individual.
- Corrección de recorte de ventanas raster parcialmente fuera de la imagen.
- Lectura TIFF simplificada: se retiran `tifffile` e `imagecodecs`, que ya no se usan.

### Interfaz
- Etiqueta GeoJSON actualizada a “lotes y focos AGIS”.
- Vista previa tolerante a columnas opcionales.
- Validación antes de habilitar la generación del informe.
- Errores de generación diferenciados de errores de lectura.

## Pruebas realizadas con Valle Manzano — 02/11/2026

- CSV: 76 filas, 48 columnas.
- GeoJSON: 76 geometrías.
- TIFF: 3 bandas, 684 x 523, EPSG:4326, nodata -9999.
- Validación de contrato CSV: sin errores.
- Correspondencia CSV ↔ GeoJSON: sin diferencias (76/76).
- Intersección espacial con TIFF: 76/76 geometrías.
- Prioridades: 12 altas, 14 medias, 50 seguimiento.
- Estado `NO_CONCLUYENTE`: verificado como “No concluyente”.
- Compilación Python de la aplicación y módulos: correcta.
- Generación de PDF: correcta, 31 páginas.

## Límite importante de la prueba
El entorno aislado de armado no tenía instalada la librería `contextily`. Para probar la composición PDF se simuló la ausencia de teselas de fondo: se validaron geometrías, capas raster, recortes y armado del documento, pero NO se verificó la descarga/renderizado de imagen satelital de Esri. La prueba final de fondo satelital y la ejecución real de Streamlit deben hacerse en el nuevo despliegue, con `pip install -r requirements.txt`.

## Observación cartográfica
El mapa general contiene todos los lotes, pero los lotes del establecimiento se distribuyen en varios grupos espaciales. Por eso el mapa de conjunto conserva espacios entre grupos; no se deben acercar artificialmente ni deformar las distancias para llenar la página. La legibilidad final debe revisarse en el despliegue y, si se requiere mayor detalle, la mejora adecuada sería agregar mapas de detalle por sector, manteniendo el mapa general como referencia.

## Estado
Candidato consolidado para pruebas en un repositorio separado. No reemplazar producción hasta completar prueba de interfaz y verificar el fondo satelital.
