# AGIS · Generador de informes de monitoreo

Aplicación Streamlit para validar archivos de salida de AGIS y generar informes PDF.

## Archivos de entrada

- **CSV AGIS:** registros y estados generados por el motor.
- **GeoJSON:** geometrías de lotes y, cuando existan, focos/alertas.
- **TIFF:** raster multibanda. Contrato de referencia: B1 SAR VV, B2 NDRE, B3 NDMI. Se mantiene compatibilidad de lectura con TIFF de 2 bandas.

Los tres archivos deben pertenecer a la misma ejecución y establecimiento. Las fechas de adquisición satelital pueden diferir según la fuente; CSV, GeoJSON y TIFF deben representar el mismo período de monitoreo.

## Instalación local (Windows)

Abrir PowerShell en esta carpeta y ejecutar:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Si PowerShell bloquea la activación:

```powershell
.venv\Scripts\python.exe -m streamlit run app.py
```

## Validaciones incorporadas

- Contrato de columnas y consistencia básica del CSV.
- IDs únicos en CSV y correspondencia exacta con GeoJSON.
- Geometrías válidas y CRS.
- Cantidad de bandas, dimensiones, CRS y nodata del TIFF.
- Intersección espacial entre las geometrías y la extensión del raster.

## Contrato raster

- Banda 1: SAR VV
- Banda 2: NDRE
- Banda 3: NDMI

## Alcance

La aplicación presenta los resultados ya calculados por AGIS. No recalcula diagnósticos, hipótesis, confianza ni prioridades agronómicas.
